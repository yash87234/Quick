.navbar {
    padding: 20px 30px ;
    background-color: white;
}

.navbarButton {
    position: relative;
    background-color: white;
}

.groupButton {
    z-index: 10;
    border: 1px solid gray;
    box-shadow: 2px 2px silver;
    border-radius: 5px;
    width: 110px;
    height: 35px;
    padding: 5px 5px;
    justify-content: space-evenly;
}

.dropDown {
    position: absolute;
    width: 250px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    gap: 10px;
    padding: 5px;
    margin: 10px 5px 5px 0px;
    border: 1px solid gray;
    border-radius: 7px;
    box-shadow: 2px 2px silver;
    z-index: 10;
}

.group {
    padding: 8px 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

select {
    width: 100px;
    padding: 2px 5px;
    border: 1px solid silver;
    border-radius: 4px;
    background-color: white;
}
